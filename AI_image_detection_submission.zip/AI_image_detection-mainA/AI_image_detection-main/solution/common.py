#Shared configuration and utilities
import csv
import io
import json
import os
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from PIL import Image
from scipy.stats import beta as beta_dist
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score

IMG_SIZE = 96
BATCH = 128
LR = 2e-3
SEED = 42
TARGET_FPR = 0.20
CAL_TARGET_FPR = 0.15
CALIBRATION_CONFIDENCE = 0.90
BENCHMARK_TIME = 1800
TRAIN_BUDGET_SECONDS = BENCHMARK_TIME * 5 * 0.95

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
ARTIFACTS_DIR = BASE_DIR / "artifacts"


def set_seed(seed=SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(min(8, os.cpu_count() or 1))
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
        

def set_benchmark_time(seconds=BENCHMARK_TIME):
    global BENCHMARK_TIME
    BENCHMARK_TIME = seconds

def image_bytes(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    if isinstance(value, dict) and "bytes" in value:
        return image_bytes(value["bytes"])
    raise ValueError(f"Unsupported image cell type: {type(value)}")


def decode_image(value):
    with Image.open(io.BytesIO(image_bytes(value))) as image:
        image = image.convert("RGB").resize(
            (IMG_SIZE, IMG_SIZE), Image.Resampling.BILINEAR
        )
        return np.asarray(image, dtype=np.uint8)

# load_split function is used to load the dataset splits (train, validation, predict) from parquet files. It reads the image data and labels (if available) and returns them as numpy arrays. 
# The function also handles cases where the label column may have different names or may not be present at all.
def load_split(name, with_source=False):

    files = sorted((DATA_DIR / name).glob("*.parquet"))
    if not files:
        raise FileNotFoundError(f"No parquet files in {DATA_DIR / name}")

    frame = pd.concat([pd.read_parquet(path) for path in files], ignore_index=True)
    images = np.stack([decode_image(value) for value in frame["image"]])

    label_column = next(
        (column for column in ("source_class", "source class") if column in frame),
        None,
    )
    if label_column is not None:
        source = frame[label_column].to_numpy(dtype=np.int64)
        labels = (source != 0).astype(np.int64)
        return (images, labels, source) if with_source else (images, labels)

    row_column = next(
        (column for column in ("row_id", "row id") if column in frame),
        None,
    )
    if row_column is None:
        raise ValueError(f"No labels or row IDs in split '{name}'")
    if with_source:
        raise ValueError("with_source=True is valid only for labeled splits")
    return images, frame[row_column].to_numpy(dtype=np.int64)


class SmallCNN(nn.Module):
    """CPU-friendly CNN retaining fine details before downsampling."""

    def __init__(self, channels=32):
        super().__init__()

        def block(in_channels, out_channels, stride=1):
            return nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=3,
                    stride=stride,
                    padding=1,
                    bias=False,
                ),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )

        self.net = nn.Sequential(
            # Preserve fine-scale information initially.
            block(3, channels, stride=1),
            block(channels, channels, stride=2),

            block(channels, 2 * channels, stride=1),
            block(2 * channels, 2 * channels, stride=2),

            block(2 * channels, 4 * channels, stride=1),
            block(4 * channels, 4 * channels, stride=2),

            block(4 * channels, 4 * channels, stride=1),

            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(4 * channels, 1),
        )

    def forward(self, inputs):
        return self.net(inputs).squeeze(1)


def score_images(model, images, batch_size=BATCH):
    model.eval()
    tensor = torch.from_numpy(np.ascontiguousarray(images)).permute(0, 3, 1, 2)
    scores = []
    with torch.no_grad():
        for start in range(0, len(tensor), batch_size):
            batch = tensor[start:start + batch_size].float().div_(255.0)
            scores.append(torch.sigmoid(model(batch)).cpu())
    return torch.cat(scores).numpy() if scores else np.empty(0, dtype=np.float32)


# Calibrates a decision threshold from real-image scores so that the true
# FPR stays below TARGET_FPR with high confidence, even on a small
# calibration set. Combines the naive empirical (1 - target_fpr) quantile
# with a Clopper-Pearson upper-bound guard, and returns the stricter
# (higher) of the two thresholds.
def calibrate_threshold(real_scores, target_fpr=CAL_TARGET_FPR):
    real_scores = np.asarray(real_scores, dtype=np.float64)
    empirical = float(np.quantile(real_scores, 1.0 - target_fpr, method="higher"))

    ordered = np.sort(real_scores)[::-1]
    n = len(ordered)
    allowed = np.arange(n)
    upper_bounds = beta_dist.ppf(CALIBRATION_CONFIDENCE, allowed + 1, n - allowed)
    valid = np.flatnonzero(upper_bounds <= TARGET_FPR)
    max_allowed = int(valid.max()) if len(valid) else 0
    guard = float(ordered[max_allowed]) if max_allowed < n else float(ordered[-1])

    return max(empirical, guard)


def evaluate(labels, scores, threshold):
    labels = np.asarray(labels, dtype=np.int64)
    scores = np.asarray(scores, dtype=np.float64)
    predictions = (scores > threshold).astype(np.int64)
    tn, fp, fn, tp = confusion_matrix(labels, predictions, labels=[0, 1]).ravel()
    recall = float(recall_score(labels, predictions, zero_division=0))
    manual_recall = float(tp / (tp + fn)) if tp + fn else 0.0
    if abs(recall - manual_recall) > 1e-12:
        raise RuntimeError(
            f"recall mismatch: sklearn={recall} manual={manual_recall}"
        )
    return {
        "recall": recall,
        "precision": float(precision_score(labels, predictions, zero_division=0)),
        "f1": float(f1_score(labels, predictions, zero_division=0)),
        "roc_auc": float(roc_auc_score(labels, scores)),
        "fpr": float(fp / (fp + tn)) if fp + tn else 0.0,
        "fnr": float(fn / (fn + tp)) if fn + tp else 0.0,
        "confusion_matrix": [[int(tn), int(fp)], [int(fn), int(tp)]],
    }


def stratified_split(labels, validation_fraction, rng):
    real = rng.permutation(np.flatnonzero(labels == 0))
    ai = rng.permutation(np.flatnonzero(labels == 1))
    n_real = max(1, round(validation_fraction * len(real)))
    n_ai = max(1, round(validation_fraction * len(ai)))
    validation = np.concatenate((real[:n_real], ai[:n_ai]))
    training = np.concatenate((real[n_real:], ai[n_ai:]))
    return rng.permutation(training), rng.permutation(validation)


def balanced_cycle(real_indices, ai_indices, rng):
    sampled_ai = rng.choice(
        ai_indices,
        size=len(real_indices),
        replace=len(ai_indices) < len(real_indices),
    )
    return rng.permutation(np.concatenate((real_indices, sampled_ai)))


def save_model(model, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(model.state_dict(), temporary)
    temporary.replace(path)


def save_json(data, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, allow_nan=False)
    temporary.replace(path)


def run_prediction(model_file, threshold_file, task_name):
    set_seed()
    models_dir = ARTIFACTS_DIR / "models"

    model = SmallCNN()
    model.load_state_dict(
        torch.load(models_dir / model_file, map_location="cpu", weights_only=True)
    )
    with (models_dir / threshold_file).open(encoding="utf-8") as handle:
        threshold = float(json.load(handle)["threshold"])

    images, row_ids = load_split("predict")
    predictions = (score_images(model, images) > threshold).astype(np.int64)

    output = ARTIFACTS_DIR / task_name / "predictions.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(("row_id", "predicted_label"))
        writer.writerows(zip(row_ids, predictions))

    print(
        f"Wrote {len(predictions)} predictions "
        f"({int(predictions.sum())} AI) -> {output}"
    )
