import argparse
import io
import time

import numpy as np
import torch
import torch.nn as nn
from PIL import Image, ImageFilter

# the common module contains shared utilities and constants for the training scripts
# we've put the best parameters in the default values of the command-line arguments, so some of the values below are not used in the final submission.
from common import (
    ARTIFACTS_DIR,
    BATCH,
    CAL_TARGET_FPR,
    IMG_SIZE,
    LR,
    SEED,
    TARGET_FPR,
    TRAIN_BUDGET_SECONDS,
    SmallCNN,
    balanced_cycle,
    calibrate_threshold,
    evaluate,
    load_split,
    save_json,
    save_model,
    score_images,
    set_seed,
    stratified_split,
)

MARGIN_SECONDS = 240
VALIDATION_FRACTION = 0.10
VALIDATE_EVERY = 50
SCHEDULER_CYCLES = 18

AUGMENTATION_PROBABILITY = 0.50
FINAL_CALIBRATION_FPR = 0.16
FINE_TUNE_LR = LR / 4
INITIAL_VALIDATION_SECONDS = 15.0
AUG_RESOLUTION = 320
JPEG_QUALITY = (15, 75)
BLUR_RADIUS = (1.0, 4.5)
RESCALE_SCALE = (0.15, 0.6)
NOISE_SIGMA = (8.0, 30.0)


def augment_image(image, rng):
    choice = int(rng.integers(4))
    large = Image.fromarray(image).resize(
        (AUG_RESOLUTION, AUG_RESOLUTION), Image.Resampling.BILINEAR
    )

    # JPEG compression
    if choice == 0:
        buffer = io.BytesIO()
        large.save(
            buffer, format="JPEG", quality=int(rng.integers(*JPEG_QUALITY))
        )
        buffer.seek(0)
        with Image.open(buffer) as decoded:
            large = decoded.convert("RGB")
            resized = large.resize((IMG_SIZE, IMG_SIZE), Image.Resampling.BILINEAR)
            return np.asarray(resized, dtype=np.uint8)

    # gaussian blur
    if choice == 1:
        large = large.filter(
            ImageFilter.GaussianBlur(float(rng.uniform(*BLUR_RADIUS)))
        )
    # rescaling
    elif choice == 2:
        side = max(8, int(AUG_RESOLUTION * float(rng.uniform(*RESCALE_SCALE))))
        large = large.resize((side, side), Image.Resampling.BILINEAR)
    else:
        # additive Gaussian noise
        values = np.asarray(large, dtype=np.float32)
        values += rng.normal(0.0, float(rng.uniform(*NOISE_SIGMA)), values.shape)
        large = Image.fromarray(np.clip(values, 0, 255).astype(np.uint8))

    # resize back to the target size
    resized = large.resize((IMG_SIZE, IMG_SIZE), Image.Resampling.BILINEAR)
    return np.asarray(resized, dtype=np.uint8)


def augment_batch(images, rng, probability=AUGMENTATION_PROBABILITY):
    output = np.ascontiguousarray(images).copy()
    for index in np.flatnonzero(rng.random(len(output)) < probability):
        output[index] = augment_image(output[index], rng)
    return output

def fixed_augmented_view(images, rng, batch_size):
    return np.concatenate(
        [
            augment_batch(images[start:start + batch_size], rng, probability=1.0)
            for start in range(0, len(images), batch_size)
        ]
    )

# validate the model on both clean and augmented validation sets. Use the higher of the two thresholds to ensure that the final model is robust to both clean and augmented images.
def validate(model, clean_images, augmented_images, labels, fpr_target=CAL_TARGET_FPR):
    clean_scores = score_images(model, clean_images)
    augmented_scores = score_images(model, augmented_images)
    clean_threshold = calibrate_threshold(
        clean_scores[labels == 0], fpr_target
    )
    augmented_threshold = calibrate_threshold(
        augmented_scores[labels == 0], fpr_target
    )
    threshold = max(clean_threshold, augmented_threshold)
    return {
        "threshold": threshold,
        "clean": evaluate(labels, clean_scores, threshold),
        "augmented": evaluate(labels, augmented_scores, threshold),
    }

# parser used for automatic hyperparameter tuning. The default values are the best parameters found in the final submission.
def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout_seconds", type=int, default=1800)
    parser.add_argument("--train_budget_seconds", type=int, default=TRAIN_BUDGET_SECONDS)
    parser.add_argument("--batch_size", type=int, default=96)
    parser.add_argument("--lr", type=float, default=0.00026645364508755937)
    parser.add_argument("--fine_tune_lr", type=float, default=2.258641890358351e-06)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--validation_fraction", type=float, default=0.12563660363002055)
    parser.add_argument("--scheduler_cycles", type=int, default=13)
    parser.add_argument(
        "--augmentation_probability",
        type=float,
        default=0.7647802697518075,
    )
    parser.add_argument(
        "--final_calibration_fpr", type=float, default=0.17909396998760957
    )
    parser.add_argument("--channels", type=int, default=32)
    parser.add_argument("--weight_decay", type=float, default=2.549894768921286e-06)
    parser.add_argument("--max_steps", type=int, default=1093)
    return parser


def main():
    print("start of augmented training! IMPORTANT: WE'VE SET DEFAULT TRAIN BUDGET SECONDS TO 1800s, IT SHOULD STOP AT STEP 1093")
    args = build_parser().parse_args()
    if args.timeout_seconds <= MARGIN_SECONDS:
        raise ValueError(f"timeout must exceed {MARGIN_SECONDS}s")

    set_seed(args.seed)
    started = time.perf_counter()
    budget = min(args.timeout_seconds - MARGIN_SECONDS, args.train_budget_seconds)
    deadline = started + budget

    task2_path = ARTIFACTS_DIR / "models" / "model.pt"
    model_path = ARTIFACTS_DIR / "models" / "model_aug.pt"
    threshold_path = ARTIFACTS_DIR / "models" / "threshold_aug.json"
    metrics_path = ARTIFACTS_DIR / "metrics" / "task03.json"
    if not task2_path.exists():
        raise FileNotFoundError(f"Run train.py first: {task2_path} is missing")

    cache = np.load(ARTIFACTS_DIR / "prepared" / "train.npz", mmap_mode="r")
    images = cache["X"]
    labels = np.asarray(cache["y"], dtype=np.int64)

    rng = np.random.default_rng(args.seed)
    train_indices, validation_indices = stratified_split(
        labels, args.validation_fraction, rng
    )
    real_indices = train_indices[labels[train_indices] == 0]
    ai_indices = train_indices[labels[train_indices] == 1]
    if not len(real_indices) or not len(ai_indices):
        raise RuntimeError("Both classes are required")

    tensor_labels = torch.from_numpy(labels.astype(np.float32))
    clean_validation = np.ascontiguousarray(images[validation_indices])
    validation_labels = labels[validation_indices]
    augmented_validation = fixed_augmented_view(
        clean_validation, np.random.default_rng(args.seed + 1), args.batch_size
    )

    #model setup
    model = SmallCNN(channels=args.channels)
    model.load_state_dict(
        torch.load(task2_path, map_location="cpu", weights_only=True)
    )
    fine_tune_lr = args.fine_tune_lr if args.fine_tune_lr is not None else args.lr / 100.0
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=args.scheduler_cycles, eta_min=fine_tune_lr
    )
    criterion = nn.BCEWithLogitsLoss()
    save_model(model, model_path)

    best = {
        "augmented_recall": -1.0,
        "clean_recall": -1.0,
        "mean_auc": -1.0,
        "step": 0,
    }
    steps = images_seen = completed_cycles = 0
    training_time = validation_time = 0.0
    validation_estimate = INITIAL_VALIDATION_SECONDS
    last_validated_step = 0

    order = balanced_cycle(real_indices, ai_indices, rng)
    cursor = 0

    #inline function to run validation and update best model
    def run_validation(reason):
        nonlocal validation_time, validation_estimate, last_validated_step, best

        start = time.perf_counter()
        metrics = validate(
            model, clean_validation, augmented_validation, validation_labels, args.final_calibration_fpr
        )
        duration = time.perf_counter() - start
        validation_time += duration
        validation_estimate = max(5.0, 0.5 * (validation_estimate + duration))
        last_validated_step = steps

        clean = metrics["clean"]
        augmented = metrics["augmented"]
        mean_auc = 0.5 * (clean["roc_auc"] + augmented["roc_auc"])
        better = (
            augmented["recall"] > best["augmented_recall"] + 1e-12
            or (
                abs(augmented["recall"] - best["augmented_recall"]) <= 1e-12
                and clean["recall"] > best["clean_recall"] + 1e-12
            )
            or (
                abs(augmented["recall"] - best["augmented_recall"]) <= 1e-12
                and abs(clean["recall"] - best["clean_recall"]) <= 1e-12
                and mean_auc > best["mean_auc"] + 1e-12
            )
        )
        if better:
            best = {
                "augmented_recall": augmented["recall"],
                "clean_recall": clean["recall"],
                "mean_auc": mean_auc,
                "step": steps,
            }
            save_model(model, model_path)

        print(
            f"validation {reason} step={steps}: "
            f"clean_recall={clean['recall']:.4f} clean_fpr={clean['fpr']:.4f} "
            f"aug_recall={augmented['recall']:.4f} aug_fpr={augmented['fpr']:.4f} "
            f"{'saved' if better else 'unchanged'}"
        )

    print(
        f"Task 3: {len(images)} images, batch={args.batch_size}, budget={budget}s, "
        f"augmentation_probability={args.augmentation_probability:.2f}, max_steps={args.max_steps}"
    )

    # train loop
    while steps < args.max_steps and deadline - time.perf_counter() > validation_estimate + 5.0:
        if cursor >= len(order):
            completed_cycles += 1
            if completed_cycles <= args.scheduler_cycles:
                scheduler.step()
            order = balanced_cycle(real_indices, ai_indices, rng)
            cursor = 0

        batch_indices = order[cursor:cursor + args.batch_size]
        cursor += len(batch_indices)
        index_tensor = torch.from_numpy(batch_indices)

        batch_start = time.perf_counter()
        augmented = augment_batch(
            np.ascontiguousarray(images[batch_indices]), rng, args.augmentation_probability
        )
        batch_images = (
            torch.from_numpy(augmented)
            .permute(0, 3, 1, 2)
            .float()
            .div_(255.0)
        )
        batch_labels = tensor_labels[index_tensor]

        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss = criterion(model(batch_images), batch_labels)
        loss.backward()
        optimizer.step()
        training_time += time.perf_counter() - batch_start

        steps += 1
        images_seen += len(batch_indices)
        if steps == 1 or steps % 100 == 0:
            rate = images_seen / training_time if training_time else 0.0
            print(
                f"step={steps} loss={loss.item():.4f} "
                f"lr={optimizer.param_groups[0]['lr']:.6f} img/s={rate:.1f}"
            )

        if steps % VALIDATE_EVERY == 0:
            remaining = deadline - time.perf_counter()
            if remaining > 2 * validation_estimate + 5.0:
                run_validation("periodic")

    if steps > last_validated_step or best["step"] == 0:
        run_validation("final")
    #end training loop

    #final calibration and evaluation
    model.load_state_dict(
        torch.load(model_path, map_location="cpu", weights_only=True)
    )
    clean_calibration, clean_labels = load_split("calibration")
    augmented_calibration, augmented_labels = load_split("calibration_augmented")
    clean_scores = score_images(model, clean_calibration)
    augmented_scores = score_images(model, augmented_calibration)

    clean_threshold = calibrate_threshold(
        clean_scores[clean_labels == 0], args.final_calibration_fpr
    )
    augmented_threshold = calibrate_threshold(
        augmented_scores[augmented_labels == 0], args.final_calibration_fpr
    )
    threshold = max(clean_threshold, augmented_threshold)
    save_json(
        {
            "threshold": threshold,
            "threshold_clean": clean_threshold,
            "threshold_augmented": augmented_threshold,
            "target_fpr": args.final_calibration_fpr,
        },
        threshold_path,
    )

    results = {
        "threshold": threshold,
        "threshold_clean": clean_threshold,
        "threshold_augmented": augmented_threshold,
        "training": {
            "steps": steps,
            "images_seen": images_seen,
            "completed_balanced_cycles": completed_cycles,
            "best_step": best["step"],
            "best_internal_augmented_recall": best["augmented_recall"],
            "best_internal_clean_recall": best["clean_recall"],
            "best_internal_mean_auc": best["mean_auc"],
            "training_seconds": training_time,
            "internal_validation_seconds": validation_time,
        },
    }

    results["calibration_augmented"] = evaluate(
        augmented_labels, augmented_scores, threshold
    )
    for split in ("validation", "validation_augmented"):
        split_images, split_labels = load_split(split)
        results[split] = evaluate(
            split_labels, score_images(model, split_images), threshold
        )

    results["elapsed_seconds"] = time.perf_counter() - started
    save_json(results, metrics_path)

    for split in ("calibration_augmented", "validation", "validation_augmented"):
        metrics = results[split]
        print(   
            f"{split}: recall={metrics['recall']:.4f} "
            f"fpr={metrics['fpr']:.4f} auc={metrics['roc_auc']:.4f}"
        )
    if any(results[split]["fpr"] > TARGET_FPR for split in results if split.startswith("validation")):
        print(f"WARNING: an FPR exceeds {TARGET_FPR:.2f}")
    print(
        f"Task 3 complete: best_step={best['step']}/{steps}, "
        f"threshold={threshold:.6f}, elapsed={results['elapsed_seconds']:.1f}s"
    )

if __name__ == "__main__":
    main()
